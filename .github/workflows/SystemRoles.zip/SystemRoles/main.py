import discord
from discord.ext import commands
from config import BOT_TOKEN, GUILD_ID

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

class AutoSyncBot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix='!',
            intents=intents,
            help_command=None
        )

    async def setup_hook(self):
        cogs = [
            'System.DeleteRole',
            'System.TakeRole',
            'System.GiveRole',
            'System.RenameRole',
            'System.ColorRole',
            'System.CreateRole',
            'System.AutoRoleMembers',
            'System.AutoRoleBots',
            'System.IconRole',
            'System.Help'
        ]
        
        for cog in cogs:
            try:
                await self.load_extension(cog)
                print(f'[✔] {cog}')
            except Exception as e:
                print(f'[✘] {cog}: {str(e)}')
        guild = discord.Object(id=GUILD_ID)
        self.tree.copy_global_to(guild=guild)
        await self.tree.sync(guild=guild)
        print("""
██╗    ██╗██╗ ██████╗██╗  ██╗    ███████╗████████╗██╗   ██╗██████╗ ██╗ ██████╗ 
██║    ██║██║██╔════╝██║ ██╔╝    ██╔════╝╚══██╔══╝██║   ██║██╔══██╗██║██╔═══██╗
██║ █╗ ██║██║██║     █████╔╝     ███████╗   ██║   ██║   ██║██║  ██║██║██║   ██║
██║███╗██║██║██║     ██╔═██╗     ╚════██║   ██║   ██║   ██║██║  ██║██║██║   ██║
╚███╔███╔╝██║╚██████╗██║  ██╗    ███████║   ██║   ╚██████╔╝██████╔╝██║╚██████╔╝
 ╚══╝╚══╝ ╚═╝ ╚═════╝╚═╝  ╚═╝    ╚══════╝   ╚═╝    ╚═════╝ ╚═════╝ ╚═╝ ╚═════╝
   """)

    async def on_ready(self):
        print(f'\n{self.user.name} Is Online')
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="الأوامر التلقائية 🛠️"
            )
        )

bot = AutoSyncBot()
bot.run(BOT_TOKEN)