import discord
from discord.ext import commands
from discord import app_commands
from config import ALLOWED_ROLE_IDS# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║

class CreateRole(commands.Cog):
    def init(self, bot):
        self.bot = bot

    @commands.hybrid_command(
        name="create-role",
        description="انشاء رتبة بأسم و لون معين",
        with_app_command=True
    )
    @app_commands.describe(
        name="اسم الرتبة",
        color="لون الرتبة (مثال: #FF0000 أو red)"
    )# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
    @commands.guild_only()
    async def create_role(self, ctx: commands.Context, name: str, color: str):
        try:
            if not any(r.id in ALLOWED_ROLE_IDS["create_role"] for r in ctx.author.roles):
                embed = discord.Embed(
                    title="❌ صلاحيات مرفوضة",
                    description="ليس لديك الصلاحيات لأستخدام الامر",
                    color=discord.Color.red()
                )
                return await ctx.send(embed=embed, ephemeral=True)
            
            color = color.strip().lstrip('#')
            try:
                color_obj = discord.Color.from_str(f"#{color}" if len(color) == 6 else color)
            except ValueError:
                raise commands.BadArgument("لون غير صالح! مثال: #FF0000 أو red")
            
            new_role = await ctx.guild.create_role(
                name=name,
                color=color_obj,
                reason=f"أنشئت بواسطة {ctx.author}"# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
            )
            
            if ctx.guild.me.top_role.position > 1:
                await new_role.edit(position=ctx.guild.me.top_role.position - 1)
            
            embed = discord.Embed(
                title="✅ تم الإنشاء بنجاح",
                description=f"الرتبة: {new_role.mention}\nاللون: #{color_obj.value:06x}",
                color=color_obj
            )
            await ctx.send(embed=embed)
            
        except commands.BadArgument as e:
            await ctx.send(f"❌ {e}", ephemeral=True)
        except discord.Forbidden:
            await ctx.send("❌ البوت لا يملك صلاحية إدارة الرتب!", ephemeral=True)
        except Exception as e:
            await ctx.send(f"❌ خطأ غير متوقع: {type(e).name}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(CreateRole(bot))