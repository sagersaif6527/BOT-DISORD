import discord
import json
import os
from discord import app_commands
from discord.ext import commands
from config import ALLOWED_ROLE_IDS

class AutoRoleMembers(commands.Cog):
    def init(self, bot):
        self.bot = bot
        self.data_file = 'members.json'
        self.auto_roles = self.load_data()
        print("[✓] AutoRoleMembers.py Working")
# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
    def load_data(self):
        if not os.path.exists(self.data_file):
            with open(self.data_file, 'w') as f:
                json.dump({}, f)
            return {}
        try:# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
            with open(self.data_file, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return {}

    def save_data(self):
        with open(self.data_file, 'w') as f:
            json.dump(self.auto_roles, f, indent=4)

    @commands.hybrid_command(
        name="set-auto-role-members",
        description="تعيين رتبة تلقائية للأعضاء ",
        with_app_command=True
    )
    @app_commands.describe(role="الرتبة")
    @commands.guild_only()# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
    async def set_auto_role(self, ctx, role: discord.Role):
        try:
            if not any(r.id in ALLOWED_ROLE_IDS["auto_role_members"] for r in ctx.author.roles):
                embed = discord.Embed(
                    title="❌ صلاحيات مرفوضة",
                    description="ليس لديك الصلاحيات لأستخدام هذا الامر! ", 
                    color=discord.Color.red()
                )
                return await ctx.send(embed=embed, ephemeral=True)

            if role.position >= ctx.guild.me.top_role.position:
                embed = discord.Embed(
                    title="❌ خطأ في الترتيب",
                    description="الرتبة يجب أن تكون أسفل رتبة البوت!",
                    color=discord.Color.red()
                )
                return await ctx.send(embed=embed, ephemeral=True)

            self.auto_roles[str(ctx.guild.id)] = role.id
            self.save_data()
# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
            embed = discord.Embed(
                title="✅ تم الحفظ ",
                description=f"الرتبة {role.mention} ستعطى تلقائيا للأعضاء الجدد",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)

        except Exception as e:
            embed = discord.Embed(
                title="❌ خطأ ",
                description=f"حدث خطأ: {str(e)}",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, ephemeral=True)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        if member.bot:
            return
            # ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
        guild_id = str(member.guild.id)
        if guild_id in self.auto_roles:
            try:
                role = member.guild.get_role(int(self.auto_roles[guild_id]))
                if role:
                    await member.add_roles(role)
            except Exception as e:
                print(f"خطأ في الرتبة التلقائية: {str(e)}")

    @commands.hybrid_command(
        name="show-auto-role-members",
        description="رؤية الرتبة التلقائية",
        with_app_command=True# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
    )
    async def show_auto_role(self, ctx):
        guild_id = str(ctx.guild.id)
        role_id = self.auto_roles.get(guild_id)
        
        embed = discord.Embed(
            title=" الرتبة التلقائية 📂",
            color=discord.Color.blue()
        )
        # ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
        if role_id:
            role = ctx.guild.get_role(int(role_id))
            if role:
                embed.description = f"الرتبة التلقائية: {role.mention}"
                embed.color = role.color
            else:
                embed.description = "⚠️ الرتبة المحفوظة غير موجودة"
                embed.color = discord.Color.orange()
        else:
            embed.description = "لم يتم تعيين رتبة تلقائية"
            
        await ctx.send(embed=embed, ephemeral=True)

    @commands.hybrid_command(
        name="remove-auto-role-members",
        description="حذف الرتبة التلقائية ",
        with_app_command=True
    )
    async def remove_auto_role(self, ctx):
        guild_id = str(ctx.guild.id)
        if guild_id in self.auto_roles:
            del self.auto_roles[guild_id]
            self.save_data()
            embed = discord.Embed(
                title="✅ تم الحذف بنجاح",
                description="تم إزالة الرتبة التلقائية",
                color=discord.Color.green()
            )
        else:
            embed = discord.Embed(
                title="⚠️ لا يوجد رتبة تلقائية",
                description="لم يتم تعيين رتبة تلقائية لهذا السيرفر",
                color=discord.Color.orange()
            )
            
        await ctx.send(embed=embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(AutoRoleMembers(bot))# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║