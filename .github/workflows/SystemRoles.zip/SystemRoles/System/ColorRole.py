import discord
from discord import app_commands
from discord.ext import commands
from config import ALLOWED_ROLE_IDS# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║

class ColorRole(commands.Cog):
    def init(self, bot):
        self.bot = bot
        print("[✓] ColorRole.py Working")

    @commands.hybrid_command(
        name="color-role",
        description="تغيير لون رتبة معينة",
        with_app_command=True
    )
    @app_commands.describe(
        role="الرتبة المراد تعديل لونها",
        color_code="كود اللون (HEX أو اسم لون)"
    )# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
    @commands.guild_only()
    async def color_role(self, ctx, role: discord.Role, color_code: str):
        try:
            if not any(r.id in ALLOWED_ROLE_IDS["color_role"] for r in ctx.author.roles):
                embed = discord.Embed(
                    title="❌ صلاحيات مرفوضة",
                    description="ليس لديك الصلاحيات لأستخدام هذا الامر ", 
                    color=discord.Color.red()
                )
                return await ctx.send(embed=embed, ephemeral=True)

            if not ctx.guild.me.guild_permissions.manage_roles:
                embed = discord.Embed(
                    title="❌ نقص صلاحيات البوت",
                    description="البوت لا يمتلك صلاحية إدارة الرتب!",
                    color=discord.Color.red()
                )
                return await ctx.send(embed=embed, ephemeral=True)

            if role.is_default() or role.managed:
                embed = discord.Embed(# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
                    title="❌ رتبة نظام",
                    description="لا يمكن تعديل الرتب التلقائية أو رتب البوتات!",
                    color=discord.Color.red()
                )
                return await ctx.send(embed=embed, ephemeral=True)

            if role.position >= ctx.guild.me.top_role.position:
                embed = discord.Embed(
                    title="❌ خطأ في الترتيب",
                    description="لا يمكن تعديل رتبة أعلى من رتبة البوت!",
                    color=discord.Color.red()
                )
                return await ctx.send(embed=embed, ephemeral=True)

            color = discord.Color.from_str(color_code)
            
            old_color = role.color
            await role.edit(color=color)# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
            
            embed = discord.Embed(
                title="✅ تم تغيير اللون بنجاح",
                description=(
                    f"الرتبة: {role.mention}\n"
                    f"اللون القديم: {str(old_color)}\n"
                    f"اللون الجديد: {color_code}"
                ),
                color=color# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
            )
            await ctx.send(embed=embed)

        except ValueError:
            embed = discord.Embed(
                title="❌ لون غير صالح",
                description="استخدم صيغة HEX صحيحة (#RRGGBB) أو اسم لون معروف",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, ephemeral=True)
            
        except discord.Forbidden:# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
            embed = discord.Embed(
                title="❌ صلاحيات غير كافية",
                description="البوت لا يستطيع تعديل هذه الرتبة!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, ephemeral=True)
            
        except discord.HTTPException as e:
            embed = discord.Embed(
                title="❌ خطأ في التعديل",
                description=f" الخطأ: {e.status} ({e.code})",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, ephemeral=True)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ خطأ ",
                description=f"حدث خطأ : {str(e)}",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, ephemeral=True)

async def setup(bot):# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
    await bot.add_cog(ColorRole(bot))