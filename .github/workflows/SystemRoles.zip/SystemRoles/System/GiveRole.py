import discord
from discord import app_commands# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
from discord.ext import commands
from config import ALLOWED_ROLE_IDS

class GiveRole(commands.Cog):# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
    def __init__(self, bot):
        self.bot = bot
        print("[✓] GiveRole.py Working")

    @commands.hybrid_command(
        name="give-role",
        description="منح رتبة محددة لعضو",
        with_app_command=True
    )
    @app_commands.describe(
        member="العضو المراد منحه الرتبة",
        role="الرتبة المطلوب منحها"
    )# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
    @commands.guild_only()
    async def give_role(self, ctx, member: discord.Member, role: discord.Role):
        try:
            if not any(r.id in ALLOWED_ROLE_IDS["give_role"] for r in ctx.author.roles):
                embed = discord.Embed(
                    title="❌ صلاحيات مرفوضة",
                    description="ليس لديك الصلاحيات اللازمة!",
                    color=discord.Color.red()
                )
                return await ctx.send(embed=embed, ephemeral=True)

            if not ctx.guild.me.guild_permissions.manage_roles:
                embed = discord.Embed(
                    title="❌ نقص صلاحيات البوت",
                    description="البوت لا يملك صلاحية إدارة الرتب!",
                    color=discord.Color.red()# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
                )
                return await ctx.send(embed=embed, ephemeral=True)

            if role.is_default() or role.managed:
                embed = discord.Embed(
                    title="❌ رتبة محمية",
                    description="لا يمكن منح الرتب التلقائية أو رتب البوتات!",
                    color=discord.Color.red()# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
                )
                return await ctx.send(embed=embed, ephemeral=True)

            if role.position >= ctx.guild.me.top_role.position:
                embed = discord.Embed(
                    title="❌ خطأ في الترتيب",
                    description="لا يمكن منح رتبة أعلى من رتبة البوت!",
                    color=discord.Color.red()
                )
                return await ctx.send(embed=embed, ephemeral=True)

            if role in member.roles:
                embed = discord.Embed(
                    title="⚠️ تنبيه",
                    description=f"{member.mention} يملك بالفعل {role.mention}",
                    color=discord.Color.orange()
                )
                return await ctx.send(embed=embed, ephemeral=True)

            await member.add_roles(role)
            # ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
            embed = discord.Embed(
                title="✅ تم اعطاء الرتبة بنجاح",
                description=f"تم ح {role.mention} لـ {member.mention}")

        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ صلاحيات غير كافية",
                description="البوت لا يستطيع إدارة هذه الرتبة!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, ephemeral=True)
            
        except discord.NotFound:
            embed = discord.Embed(# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
                title="❌ عنصر غير موجود",
                description="العضو أو الرتبة لم تعد موجودة!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, ephemeral=True)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌خطأ",
                description=f"حدث خطأ فني: {str(e)}",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, ephemeral=True)
# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
async def setup(bot):
    await bot.add_cog(GiveRole(bot))