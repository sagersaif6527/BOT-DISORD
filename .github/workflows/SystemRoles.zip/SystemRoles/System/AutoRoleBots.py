import discord# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
import json
import os
from discord import app_commands
from discord.ext import commands
from config import ALLOWED_ROLE_IDS# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║

class AutoRoleBot(commands.Cog):
    def init(self, bot):
        self.bot = bot
        self.data_file = 'bots.json'
        self.auto_roles = self.load_data()# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
        print("[✓] AutoRoleBot.py Working")

    def load_data(self):
        if not os.path.exists(self.data_file):
            with open(self.data_file, 'w') as f:
                json.dump({}, f)
            return {}
        
        try:
            with open(self.data_file, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return {}

    def save_data(self):
        with open(self.data_file, 'w') as f:
            json.dump(self.auto_roles, f, indent=4)

    @commands.hybrid_command(
        name="set-auto-role-bots",
        description="تعيين رتبة تلقائية للبوتات",
        with_app_command=True
    )
    @app_commands.describe(role="الرتبة")# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
    @commands.guild_only()
    async def set_bot_role(self, ctx, role: discord.Role):
        try:
            if not any(r.id in ALLOWED_ROLE_IDS["auto_role_bots"] for r in ctx.author.roles):
                embed = discord.Embed(
                    title="❌ صلاحيات مرفوضة",
                    description="ليس لديك الصلاحيات لأستخدام هذا الأمر!",
                    color=discord.Color.red()
                )
                return await ctx.send(embed=embed, ephemeral=True)

            if not ctx.guild.me.guild_permissions.manage_roles:
                embed = discord.Embed(
                    title="❌ نقص الصلاحيات",
                    description="البوت لا يمتلك الصلاحيات!",
                    color=discord.Color.red()
                )# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
                return await ctx.send(embed=embed, ephemeral=True)

            self.auto_roles[str(ctx.guild.id)] = role.id
            self.save_data()

            embed = discord.Embed(
                title="✅ تم الحفظ", 
                description=f"الرتبة {role.mention} ستعطى تلقائيًا للبوتات الجديدة",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)

        except Exception as e:
            embed = discord.Embed(
                title="❌ خطأ", 
                description=f"حدث خطأ أثناء حفظ الإعدادات: {str(e)}",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, ephemeral=True)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        if member.bot:
            guild_id = str(member.guild.id)# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
            if guild_id in self.auto_roles:
                try:
                    role = member.guild.get_role(int(self.auto_roles[guild_id]))
                    if role:
                        await member.add_roles(role)
                except Exception as e:
                    print(f"خطأ في الرتبة التلقائية: {str(e)}")

    @commands.hybrid_command(
        name="show-auto-role-bots",
        description="رؤية الرتبة التلقائية",
        with_app_command=True
    )
    async def show_bot_roles(self, ctx):
        embed = discord.Embed(
            title="📁 الرتبة التلقائية",
            color=discord.Color.blue()
        )# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
        
        if not self.auto_roles:
            embed.description = "لا يوجد إعدادات مخزنة حالياً"
            return await ctx.send(embed=embed, ephemeral=True)

        for guild_id, role_id in self.auto_roles.items():
            guild = self.bot.get_guild(int(guild_id))
            role = guild.get_role(role_id) if guild else None
            embed.add_field(
                name=f"سيرفر: {guild.name if guild else 'غير معروف'}",
                value=f"الرتبة: {role.mention if role else '⚠️ الرتبة محذوفة'}",
                inline=False
            )
        
        await ctx.send(embed=embed, ephemeral=True)
    @commands.hybrid_command(
        name="remove-auto-role-bots",
        description="حذف الرتبة التلقائية", 
        with_app_command=True# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
    )
    async def remove_bot_role(self, ctx):
        try:
            guild_id = str(ctx.guild.id)
            if guild_id in self.auto_roles:
                del self.auto_roles[guild_id]
                self.save_data()
                embed = discord.Embed(
                    title="✅ تم الحذف بنجاح",
                    description="تم إزالة الرتبة التلقائية ",
                    color=discord.Color.green()
                )
            else:
                embed = discord.Embed(
                    title="⚠️ لا يوجد  رتبة تلقائية",
                    description="لم يتم تعيين رتبة تلقائية لهذا السيرفر",
                    color=discord.Color.orange()
                )# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
            
            await ctx.send(embed=embed, ephemeral=True)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ خطأ في الحذف",
                description=f"حدث خطأ: {str(e)}",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, ephemeral=True)

async def setup(bot):# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
    await bot.add_cog(AutoRoleBot(bot))