import discord
import requests
from io import BytesIO# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
from PIL import Image
from discord import app_commands
from discord.ext import commands
from config import ALLOWED_ROLE_IDS

class IconRole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.MAX_SIZE = 256 * 1024
        self.IMAGE_DIMENSIONS = (256, 256)
        print("[✓] IconRole.py Working")

    @commands.hybrid_command(
        name="set-role-icon",# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
        description="تعيين أيقونة للرتبة باستخدام صورة (يتطلب 7 بوستات)",
        with_app_command=True
    )
    @app_commands.describe(
        role="الرتبة المراد تعديلها",
        image="رابط الصورة أو مرفق صورة"
    )# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
    @commands.guild_only()
    async def set_role_icon(self, ctx, role: discord.Role, image: str = None):
        try:
            if ctx.guild.premium_tier < 2:
                return await ctx.send(embed=self.create_embed(
                    "❌ متطلبات غير مكتملة",
                    "يجب أن يكون السيرفر مستوى 2 على الأقل (7 بوستات)",
                    discord.Color.red()
                ), ephemeral=True)

            if not any(r.id in ALLOWED_ROLE_IDS["icon_role"] for r in ctx.author.roles):
                return await ctx.send(embed=self.create_embed(
                    "❌ صلاحيات مرفوضة",
                    "ليس لديك الصلاحيات لأستخدام الامر",
                    discord.Color.red()
                ), ephemeral=True)# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║

            image_bytes = await self.get_image(ctx, image)
            if not image_bytes:
                return await ctx.send(embed=self.create_embed(
                    "❌ صورة غير صالحة",
                    "الرجاء إرفاق صورة أو إدخال رابط صحيح!",
                    discord.Color.red()
                ), ephemeral=True)

            if len(image_bytes) > self.MAX_SIZE:
                return await ctx.send(embed=self.create_embed(
                    "❌ حجم كبير",
                    f"الحجم الأقصى المسموح: {self.MAX_SIZE//1024}KB",
                    discord.Color.red()
                ), ephemeral=True)# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║

            img = Image.open(BytesIO(image_bytes))
            if img.size != self.IMAGE_DIMENSIONS:
                return await ctx.send(embed=self.create_embed(
                    "❌ أبعاد غير صحيحة",
                    f"يجب أن تكون الأبعاد: {self.IMAGE_DIMENSIONS[0]}x{self.IMAGE_DIMENSIONS[1]}",
                    discord.Color.red()
                ), ephemeral=True)

            await role.edit(icon=image_bytes)
            await ctx.send(embed=self.create_embed(
                "✅ تم التحديث",
                f"تم تعيين الأيقونة الجديدة لرتبة {role.mention}",
                role.color
            ))# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║

        except Exception as e:
            await ctx.send(embed=self.create_embed(
                "❌ خطأ غير متوقع",
                f"تفاصيل الخطأ: {str(e)}",
                discord.Color.red()
            ), ephemeral=True)# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║

    async def get_image(self, ctx, image_input):
        if ctx.message.attachments:
            attachment = ctx.message.attachments[0]
            if not attachment.content_type.startswith('image/'):
                return None
            return await attachment.read()

        if image_input and image_input.startswith(('http://', 'https://')):
            try:
                response = requests.get(image_input)
                if response.status_code == 200:
                    return response.content
            except:
                return None
        return None
# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
    def create_embed(self, title, description, color):
        return discord.Embed(
            title=title,
            description=description,
            color=color
        )

async def setup(bot):
    await bot.add_cog(IconRole(bot))# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║