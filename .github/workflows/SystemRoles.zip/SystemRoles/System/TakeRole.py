import discord
from discord import app_commands
from discord.ext import commands
from config import ALLOWED_ROLE_IDS

class TakeRole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        print("[✓] TakeRole.py Working")

    @commands.hybrid_command(                     
        name="take-role",
# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
        description="سحب رتبة معينة من عضو",
        with_app_command=True
    )
    @app_commands.describe(
        member="العضو المراد سحب الرتبة منه",
        role="الرتبة المطلوب سحبها"
    )
    @commands.guild_only()
    async def take_role(self, ctx, member: discord.Member, role: discord.Role):
        try:
            if not any(r.id in ALLOWED_ROLE_IDS["take_role"] for r in ctx.author.roles):
                embed = discord.Embed(
                    title="❌ صلاحيات مرفوضة",
                    description="ليس لديك الصلاحيات اللازمة لهذا الأمر!",
                    color=discord.Color.red()
                )
                return await ctx.send(embed=embed, ephemeral=True)

            if not ctx.guild.me.guild_permissions.manage_roles:
                embed = discord.Embed(
                    title="❌ صلاحيات البوت ناقصة",
                    description="البوت لا يملك صلاحية إدارة الرتب!",
                    color=discord.Color.red()
                )
                return await ctx.send(embed=embed, ephemeral=True)

            if role.is_default() or role.managed:
                embed = discord.Embed(# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
                    title="❌ رتبة محمية",
                    description="لا يمكن تعديل الرتب التلقائية أو رتب البوتات!",
                    color=discord.Color.red()
                )
                return await ctx.send(embed=embed, ephemeral=True)

            if role.position >= ctx.guild.me.top_role.position:
                embed = discord.Embed(    
# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
                    title="❌ خطأ في الترتيب",
                    description="لا يمكن تعديل رتبة أعلى من رتبة البوت!",
                    color=discord.Color.red()
                )
                return await ctx.send(embed=embed, ephemeral=True)

            if role not in member.roles:# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
                embed = discord.Embed(
                    title="❌ العضو لا يملك الرتبة",
                    description=f"{member.mention} لا يملك رتبة {role.mention}",
                    color=discord.Color.orange()
                )
                return await ctx.send(embed=embed, ephemeral=True)
            
# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
            await member.remove_roles(role)
            
            embed = discord.Embed(
                title="✅ تم السحب بنجاح",
                description=f"تم سحب {role.mention} من {member.mention}",
                color=discord.Color.green()
            )
            await ctx.send(embed=embed)
# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
        except discord.Forbidden:
            embed = discord.Embed(
                title="❌ صلاحيات غير كافية",
                description="البوت لا يستطيع إدارة هذه الرتبة!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, ephemeral=True)
            
        except discord.NotFound:
            embed = discord.Embed(
# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
                title="❌ عنصر غير موجود",# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
                description="العضو أو الرتبة لم تعد موجودة!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, ephemeral=True)
            
        except Exception as e:# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║
            embed = discord.Embed(
                title="❌ خطأ غير متوقع",
                description=f"حدث خطأ فني: {str(e)}",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(TakeRole(bot))
# ███████╗███████╗██████╗ ██╗███████╗███████╗
# ██╔════╝██╔════╝██╔══██╗██║██╔════╝██╔════╝
# ███████╗█████╗  ██████╔╝██║█████╗  ███████╗
# ╚════██║██╔══╝  ██╔══██╗██║██╔══╝  ╚════██║
# ███████║███████╗██║  ██║██║███████╗███████║